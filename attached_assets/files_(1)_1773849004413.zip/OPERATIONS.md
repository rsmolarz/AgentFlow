# AgentFlow Operations Runbook

Complete guide to deploying, running, and maintaining the AgentFlow platform in production.

---

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
3. [Replit Deployment](#replit-deployment)
4. [Production Deployment (Docker)](#production-deployment)
5. [Environment Variables Reference](#environment-variables)
6. [Database Operations](#database-operations)
7. [Scaling Guide](#scaling)
8. [Monitoring & Alerting](#monitoring)
9. [Troubleshooting](#troubleshooting)
10. [Security Checklist](#security-checklist)

---

## Prerequisites

| Dependency | Version | Purpose |
|-----------|---------|---------|
| Python | 3.12+ | Backend runtime |
| Node.js | 20+ | Frontend build |
| PostgreSQL | 16+ | Primary database |
| Redis | 7+ | Queue + streaming |
| Qdrant | 1.12+ | Vector memory |

---

## Local Development

### Quickstart (all services via Docker)
```bash
# 1. Clone and enter directory
git clone <your-fork>
cd agentflow

# 2. Start infrastructure
make docker-up

# 3. Copy and edit env vars
cp .env.example .env
# Edit .env with your API keys

# 4. Install dependencies
make install

# 5. Seed demo data
make seed

# 6. Start everything
make dev
# → API:      http://localhost:8000
# → Docs:     http://localhost:8000/docs
# → Frontend: http://localhost:5173
# → Login:    admin@agentflow.dev / changeme
```

### Running services individually
```bash
make api       # FastAPI only
make worker    # Celery worker only
make frontend  # React dev server only
```

### Run the end-to-end demo
```bash
python demo.py
```

### Run tests
```bash
make test           # All tests
make test-cov       # With HTML coverage report
```

---

## Replit Deployment

1. **Import repo** into Replit (File → Import from GitHub or upload ZIP)

2. **Set Secrets** (Replit sidebar → Secrets):
   ```
   DATABASE_URL         postgresql+asyncpg://...
   REDIS_URL            redis://...
   QDRANT_URL           http://...
   SECRET_KEY           <generate: python -c "import secrets; print(secrets.token_hex(32))">
   MASTER_ENCRYPTION_KEY <generate: same>
   OPENAI_API_KEY       sk-...
   ```

3. **Click Run** — `start.sh` boots API + Celery worker + React dev server

4. **For persistent infrastructure**, use:
   - [Neon](https://neon.tech) (PostgreSQL)
   - [Upstash](https://upstash.com) (Redis)
   - [Qdrant Cloud](https://cloud.qdrant.io) (Vector DB)

   All three have free tiers sufficient for development.

---

## Production Deployment

### Single-server Docker Compose
```bash
# Generate production secrets
make generate-keys
# Copy output to .env, also set POSTGRES_PASSWORD, REDIS_PASSWORD, QDRANT_API_KEY

# Build images
make build

# Start production stack
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Run migrations
docker compose exec api alembic upgrade head

# Seed initial data
docker compose exec api python seed.py
```

### Environment-specific configs
```bash
# Scale API workers
docker compose up -d --scale api=3

# Scale Celery workers (match to CPU cores)
docker compose up -d --scale worker=4
```

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✓ | PostgreSQL connection string |
| `REDIS_URL` | ✓ | Redis connection string |
| `SECRET_KEY` | ✓ | 32-char JWT signing secret — **never reuse** |
| `MASTER_ENCRYPTION_KEY` | ✓ | 32-char AES master key for credential vault |
| `QDRANT_URL` | ✓ | Qdrant service URL |
| `QDRANT_API_KEY` | Cloud only | Qdrant Cloud API key |
| `OPENAI_API_KEY` | Recommended | Platform default LLM key |
| `ANTHROPIC_API_KEY` | Optional | Anthropic platform key |
| `LANGFUSE_SECRET_KEY` | Optional | Enables full LLM tracing |
| `LANGFUSE_PUBLIC_KEY` | Optional | Enables full LLM tracing |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Optional | OpenTelemetry collector URL |

### Generating secure keys
```bash
python -c "import secrets; print('SECRET_KEY=' + secrets.token_hex(32))"
python -c "import secrets; print('MASTER_ENCRYPTION_KEY=' + secrets.token_hex(32))"
```

---

## Database Operations

### Migrations
```bash
# Apply all pending migrations
make migrate

# Create a new migration (after changing models)
make migrate-new msg="add_workflow_tags"

# Roll back one migration
cd backend && alembic downgrade -1

# View migration history
cd backend && alembic history --verbose
```

### Tenant schema management
Each tenant gets a PostgreSQL schema: `tenant_{uuid}`. To add a new tenant:
```bash
# Via API
POST /api/v1/tenants  {"name": "Acme Corp", "slug": "acme", "plan": "enterprise"}
# This automatically creates the tenant schema and runs migrations
```

### Backups
```bash
# Full backup
pg_dump agentflow > backup_$(date +%Y%m%d).sql

# Tenant-specific backup (schema isolation enables this)
pg_dump -n tenant_<uuid> agentflow > tenant_backup.sql

# Restore
psql agentflow < backup_20250115.sql
```

### Vector DB maintenance
```bash
# List Qdrant collections (one per tenant)
curl http://localhost:6333/collections

# Delete a tenant's vector memory (when offboarding)
curl -X DELETE http://localhost:6333/collections/tenant_<uuid>
```

---

## Scaling

### Bottleneck identification
| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Slow API responses | DB pool exhausted | ↑ `DB_POOL_SIZE`, add read replica |
| SSE connections dropping | Nginx timeout | ↑ `proxy_read_timeout` in nginx.conf |
| Celery tasks queuing | Too few workers | ↑ `--concurrency` or `--scale worker` |
| High Redis memory | Stream accumulation | ↓ `REDIS_STREAM_MAXLEN` |
| Slow vector search | Qdrant under-resourced | Upgrade Qdrant tier or enable HNSW indexing |

### Horizontal scaling recipe
```bash
# Add API servers (stateless — scales freely)
docker compose up -d --scale api=4

# Add Celery workers (scale to LLM parallelism limit)
docker compose up -d --scale worker=8 -e CELERY_CONCURRENCY=4

# PostgreSQL read replicas (for read-heavy workloads)
# Add replica URL to DATABASE_URL_READONLY in config.py
```

### Per-tenant resource quotas
Configure in `src/config.py`:
```python
DEFAULT_MAX_CONCURRENT_EXECUTIONS = 10   # Per tenant
DEFAULT_MONTHLY_TOKEN_BUDGET = 10_000_000  # 10M tokens/month
```
Override per tenant via `PATCH /api/v1/tenants/{id}`.

---

## Monitoring

### Built-in endpoints
```
GET /health          Liveness probe (always fast)
GET /health/deep     Readiness probe (checks all services)
GET /metrics         Prometheus metrics (add prometheus-client)
```

### Recommended stack
```yaml
# Add to docker-compose.prod.yml
  prometheus:
    image: prom/prometheus
    volumes: [./prometheus.yml:/etc/prometheus/prometheus.yml]
    ports: ["9090:9090"]

  grafana:
    image: grafana/grafana
    ports: ["3001:3000"]
    environment:
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD}
```

### Key metrics to alert on
| Metric | Warning | Critical |
|--------|---------|---------|
| API p95 latency | > 2s | > 10s |
| Celery queue depth | > 50 | > 500 |
| DB connection pool usage | > 70% | > 90% |
| Redis memory | > 70% | > 90% |
| Monthly token budget per tenant | > 80% | > 95% |
| Failed executions (last 1h) | > 5 | > 20 |

### LLM Observability with Langfuse
```bash
# Self-host Langfuse
docker run -d -p 3000:3000 \
  -e DATABASE_URL=postgresql://... \
  langfuse/langfuse:latest

# Set in .env
LANGFUSE_HOST=http://localhost:3000
LANGFUSE_SECRET_KEY=sk-lf-...
LANGFUSE_PUBLIC_KEY=pk-lf-...
```

---

## Troubleshooting

### Common issues

**`ImportError: No module named 'src'`**
```bash
cd backend && pip install -e .
# or run: PYTHONPATH=backend python -m src.main
```

**Celery worker not picking up tasks**
```bash
# Check broker connectivity
cd backend && celery -A src.workers.celery_app inspect ping

# Check which queues are registered
cd backend && celery -A src.workers.celery_app inspect active_queues
```

**SSE stream disconnects immediately**
- Check Nginx `proxy_read_timeout` is >= 3600s
- Ensure `X-Accel-Buffering: no` header is set
- Verify CORS allows your frontend origin

**Database migrations fail on new tenant**
```bash
# Manually create schema and run migrations
cd backend && python -c "
import asyncio
from src.core.database import create_tenant_schema
asyncio.run(create_tenant_schema('your-tenant-uuid'))
"
```

**Qdrant collection doesn't exist**
- Memory manager auto-creates collections on first write
- To manually create: `curl -X PUT http://localhost:6333/collections/tenant_<id> -d '{"vectors": {"size": 1536, "distance": "Cosine"}}'`

**JWT token expired**
```bash
# Get new token
curl -X POST http://localhost:8000/api/v1/auth/refresh \
  -d '{"refresh_token": "your-refresh-token"}'
```

---

## Security Checklist

Before going to production, verify all items:

- [ ] `SECRET_KEY` is 64+ random hex chars, not the default
- [ ] `MASTER_ENCRYPTION_KEY` is 64+ random hex chars, not the default  
- [ ] `POSTGRES_PASSWORD` is strong and not the default `postgres`
- [ ] `REDIS_PASSWORD` is set in production
- [ ] `DEBUG=false` in production environment
- [ ] CORS origins locked down to your specific domains
- [ ] Nginx rate limiting configured (see `nginx.conf`)
- [ ] SSL/TLS certificates installed (Let's Encrypt recommended)
- [ ] `QDRANT_API_KEY` set if using Qdrant Cloud
- [ ] Database not exposed on public network (only via app containers)
- [ ] Redis not exposed on public network
- [ ] Log aggregation configured (PII sanitization for agent outputs)
- [ ] Regular credential rotation policy documented
- [ ] Backup schedule configured and tested (weekly restore drill)
- [ ] Agent `permissions` blocks reviewed for each agent definition
- [ ] Platform admin accounts use strong passwords or SSO
