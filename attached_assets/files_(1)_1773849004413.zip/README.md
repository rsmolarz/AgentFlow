# AgentFlow — Enterprise AI Agent Management Platform

The most robust open-source platform for building, orchestrating, and monitoring AI agents. Synthesizes the best of CrewAI, LangGraph, LangChain, and n8n into a unified enterprise-grade SaaS system.

## Features

- **Visual Workflow Builder** — drag-and-drop React Flow canvas with 7 node types
- **Multi-Agent Orchestration** — LangGraph-inspired StateGraph execution engine
- **4-Tier Memory System** — short-term, working, long-term (Qdrant), episodic
- **LLM-Agnostic Routing** — OpenAI, Anthropic, Groq, Ollama, any provider
- **Real-Time Streaming** — SSE-based token streaming and execution events
- **Enterprise Multi-Tenancy** — schema-per-tenant PostgreSQL isolation
- **Production Observability** — OpenTelemetry tracing, token cost attribution
- **Human-in-the-Loop** — interrupt/resume workflows with checkpoint persistence
- **Credential Vault** — AES-256-GCM encrypted API keys per tenant
- **Full RBAC** — 4-tier role hierarchy with agent-level permissions

## Tech Stack

| Layer | Technology |
|-------|-----------|
| API | FastAPI 0.115+, Python 3.12 |
| DB | PostgreSQL 16 (schema-per-tenant) |
| Queue | Celery 5.4 + Redis 7 |
| Vector | Qdrant (primary), pgvector (fallback) |
| Frontend | React 18, React Flow, TypeScript |
| Auth | OAuth2 + JWT + API Keys |
| Observability | OpenTelemetry + Langfuse |
| Streaming | SSE + Redis Pub/Sub |

## Quick Start (Replit)

1. Fork this Repl
2. Set environment variables in Replit Secrets (see `.env.example`)
3. Click **Run** — starts API + worker + frontend dev server
4. Navigate to the URL shown in the webview

## Environment Variables

```bash
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/agentflow
REDIS_URL=redis://localhost:6379
QDRANT_URL=http://localhost:6333
SECRET_KEY=your-32-char-secret-key-here
MASTER_ENCRYPTION_KEY=your-32-char-encryption-key
OPENAI_API_KEY=sk-...              # Optional — tenants set their own
ANTHROPIC_API_KEY=sk-ant-...       # Optional
LANGFUSE_SECRET_KEY=...            # Optional observability
LANGFUSE_PUBLIC_KEY=...            # Optional observability
```

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                    React Frontend                    │
│          React Flow Canvas + SSE Client             │
└────────────────────┬────────────────────────────────┘
                     │ HTTP/SSE
┌────────────────────▼────────────────────────────────┐
│              FastAPI Application                    │
│   Auth │ Agents │ Workflows │ Executions │ Stream  │
└────────────────────┬────────────────────────────────┘
          ┌──────────┼──────────┐
          │          │          │
    ┌─────▼──┐  ┌────▼───┐  ┌──▼─────┐
    │Postgres│  │ Redis  │  │ Qdrant │
    │per-    │  │Queue + │  │Vector  │
    │schema  │  │PubSub  │  │Memory  │
    └────────┘  └────────┘  └────────┘
                    │
          ┌─────────▼─────────┐
          │   Celery Workers  │
          │  Execute Graphs   │
          └───────────────────┘
```

## API Documentation

Once running, visit `/docs` for the interactive Swagger UI or `/redoc` for ReDoc.

## License

MIT
