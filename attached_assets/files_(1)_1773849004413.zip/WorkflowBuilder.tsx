import { useCallback, useEffect, useRef, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import ReactFlow, {
  Background, BackgroundVariant, Controls, MiniMap,
  addEdge, useNodesState, useEdgesState, type Connection,
  type NodeTypes, Panel, MarkerType,
} from 'reactflow'
import dagre from 'dagre'
import toast from 'react-hot-toast'
import {
  Save, Play, ArrowLeft, Plus, Layout, Cpu, Wrench, GitBranch as BranchIcon,
  Users, HelpCircle, Webhook, Layers, Loader2, StopCircle,
} from 'lucide-react'

import { AgentNode }      from './nodes/AgentNode'
import { ToolNode }       from './nodes/ToolNode'
import { ConditionNode }  from './nodes/ConditionNode'
import { HumanNode }      from './nodes/HumanNode'
import { TriggerNode }    from './nodes/TriggerNode'
import { SubworkflowNode }from './nodes/SubworkflowNode'
import { NodePanel }      from './panels/NodePanel'
import { ExecutionPanel } from './panels/ExecutionPanel'
import { useWorkflowsStore, useAgentsStore } from '../../lib/store'
import { createSSE } from '../../lib/api'
import api from '../../lib/api'

const nodeTypes: NodeTypes = {
  agent:       AgentNode,
  tool:        ToolNode,
  condition:   ConditionNode,
  human:       HumanNode,
  trigger:     TriggerNode,
  subworkflow: SubworkflowNode,
}

const NODE_MENU = [
  { type: 'agent',       icon: Cpu,         label: 'Agent Node',    color: '#00d4ff' },
  { type: 'tool',        icon: Wrench,       label: 'Tool Node',     color: '#3fb950' },
  { type: 'condition',   icon: BranchIcon,   label: 'Condition',     color: '#d29922' },
  { type: 'human',       icon: HelpCircle,   label: 'Human Input',   color: '#bc8cff' },
  { type: 'trigger',     icon: Webhook,      label: 'Trigger',       color: '#ff7b72' },
  { type: 'subworkflow', icon: Layers,       label: 'Sub-Workflow',  color: '#58a6ff' },
]

function autoLayout(nodes: any[], edges: any[]) {
  const g = new dagre.graphlib.Graph()
  g.setDefaultEdgeLabel(() => ({}))
  g.setGraph({ rankdir: 'LR', ranksep: 80, nodesep: 50 })
  nodes.forEach(n => g.setNode(n.id, { width: 200, height: 80 }))
  edges.forEach(e => g.setEdge(e.source, e.target))
  dagre.layout(g)
  return nodes.map(n => {
    const { x, y } = g.node(n.id)
    return { ...n, position: { x: x - 100, y: y - 40 } }
  })
}

export function WorkflowBuilder() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { create, update, workflows } = useWorkflowsStore()
  const { agents } = useAgentsStore()
  const reactFlowWrapper = useRef<HTMLDivElement>(null)
  const [rfInstance, setRfInstance] = useState<any>(null)

  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [workflow, setWorkflow] = useState<any>(null)
  const [selectedNode, setSelectedNode] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [running, setRunning] = useState(false)
  const [executionId, setExecutionId] = useState<string | null>(null)
  const [executionEvents, setExecutionEvents] = useState<any[]>([])
  const [showExecPanel, setShowExecPanel] = useState(false)
  const [sseRef, setSseRef] = useState<EventSource | null>(null)

  // Load existing workflow
  useEffect(() => {
    const { fetch: fetchAgents } = useAgentsStore.getState()
    fetchAgents()
    if (id) {
      const wf = workflows.find(w => w.id === id)
      if (wf) {
        setWorkflow(wf)
        const def = wf.definition as any
        setNodes(def?.nodes || [])
        setEdges(def?.edges || [])
      } else {
        api.get(`/workflows/${id}`).then(({ data }) => {
          setWorkflow(data)
          const def = data.definition as any
          setNodes(def?.nodes || [])
          setEdges(def?.edges || [])
        }).catch(() => toast.error('Workflow not found'))
      }
    }
  }, [id])

  const onConnect = useCallback((params: Connection) => {
    setEdges(eds => addEdge({
      ...params,
      animated: true,
      markerEnd: { type: MarkerType.ArrowClosed, color: 'var(--border-strong)' },
      style: { stroke: 'var(--border-strong)', strokeWidth: 2 },
    }, eds))
  }, [])

  const addNode = (type: string) => {
    const id = `${type}_${Date.now()}`
    const pos = { x: Math.random() * 400 + 100, y: Math.random() * 300 + 100 }
    const labels: Record<string, string> = {
      agent: 'New Agent', tool: 'New Tool', condition: 'Condition',
      human: 'Human Input', trigger: 'Trigger', subworkflow: 'Sub-Workflow',
    }
    setNodes(ns => [...ns, {
      id, type, position: pos,
      data: { label: labels[type] || type, type, config: {} },
    }])
  }

  const handleAutoLayout = () => {
    setNodes(ns => autoLayout(ns, edges))
    toast.success('Layout applied')
  }

  const handleSave = async () => {
    if (!rfInstance) return
    setSaving(true)
    try {
      const definition = { nodes, edges }
      if (workflow) {
        await update(workflow.id, { definition, name: workflow.name })
        toast.success('Workflow saved')
      } else {
        const wf = await create({ name: 'Untitled Workflow', definition })
        setWorkflow(wf)
        navigate(`/workflows/${wf.id}/edit`, { replace: true })
        toast.success('Workflow created')
      }
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  const handleRun = async () => {
    if (!workflow) { toast.error('Save the workflow first'); return }
    setRunning(true)
    setExecutionEvents([])
    setShowExecPanel(true)
    try {
      const { data } = await api.post(`/workflows/${workflow.id}/run`, { input_data: {} })
      setExecutionId(data.id)
      toast.success('Execution started')

      // Subscribe to SSE
      const sse = createSSE(data.id, (e: MessageEvent) => {
        try {
          const event = JSON.parse(e.data)
          setExecutionEvents(prev => [...prev, event])
          // Highlight active node
          if (event.type === 'node_status' && event.node_id) {
            setNodes(ns => ns.map(n => ({
              ...n,
              data: {
                ...n.data,
                executing: event.status === 'running' && n.id === event.node_id,
                completed: event.status === 'completed' && n.id === event.node_id,
                failed:    event.status === 'failed'    && n.id === event.node_id,
              },
            })))
          }
          if (event.type === 'execution_complete' || event.type === 'execution_failed') {
            setRunning(false)
            sse.close()
          }
        } catch {}
      })
      setSseRef(sse)
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Failed to start')
      setRunning(false)
    }
  }

  const handleCancel = async () => {
    if (!executionId) return
    sseRef?.close()
    await api.post(`/executions/${executionId}/cancel`)
    setRunning(false)
    toast.success('Execution cancelled')
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg-deep)' }}>
      {/* Toolbar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 16px', borderBottom: '1px solid var(--border-subtle)',
        background: 'var(--bg-base)', flexShrink: 0,
      }}>
        <button onClick={() => navigate('/workflows')} style={btnStyle('ghost')}>
          <ArrowLeft size={14} /> Back
        </button>
        <div style={{ width: 1, height: 20, background: 'var(--border-subtle)', margin: '0 4px' }} />

        {/* Name */}
        <input
          value={workflow?.name || 'Untitled Workflow'}
          onChange={e => setWorkflow((w: any) => ({ ...w, name: e.target.value }))}
          style={{
            background: 'transparent', border: '1px solid transparent', borderRadius: 6,
            padding: '4px 8px', color: 'var(--text-primary)', fontSize: 14, fontWeight: 600,
            outline: 'none', minWidth: 200,
          }}
          onFocus={e => (e.target as HTMLInputElement).style.borderColor = 'var(--border-default)'}
          onBlur={e => (e.target as HTMLInputElement).style.borderColor = 'transparent'}
        />

        <div style={{ flex: 1 }} />

        {/* Node adder buttons */}
        {NODE_MENU.map(({ type, icon: Icon, label, color }) => (
          <button key={type} onClick={() => addNode(type)} title={label} style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '5px 10px', borderRadius: 6, border: `1px solid ${color}30`,
            background: `${color}10`, color, cursor: 'pointer',
            fontSize: 11, fontWeight: 600, transition: 'all 0.15s',
          }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = `${color}20`}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = `${color}10`}
          >
            <Icon size={12} /> <span style={{ display: 'none' }}>{label}</span>
            <Plus size={10} />
          </button>
        ))}

        <div style={{ width: 1, height: 20, background: 'var(--border-subtle)', margin: '0 4px' }} />
        <button onClick={handleAutoLayout} style={btnStyle('ghost')} title="Auto Layout">
          <Layout size={14} />
        </button>
        <button onClick={handleSave} disabled={saving} style={btnStyle('secondary')}>
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Save
        </button>
        {running ? (
          <button onClick={handleCancel} style={btnStyle('danger')}>
            <StopCircle size={14} /> Cancel
          </button>
        ) : (
          <button onClick={handleRun} style={btnStyle('primary')}>
            <Play size={14} /> Run
          </button>
        )}
      </div>

      {/* Canvas + Panels */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div ref={reactFlowWrapper} style={{ flex: 1, position: 'relative' }}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onInit={setRfInstance}
            onNodeClick={(_, node) => setSelectedNode(node)}
            onPaneClick={() => setSelectedNode(null)}
            nodeTypes={nodeTypes}
            fitView
            deleteKeyCode="Delete"
            defaultEdgeOptions={{
              animated: true,
              markerEnd: { type: MarkerType.ArrowClosed, color: 'var(--border-strong)' },
              style: { stroke: 'var(--border-strong)', strokeWidth: 2 },
            }}
          >
            <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="rgba(255,255,255,0.04)" />
            <Controls />
            <MiniMap
              nodeColor={n => {
                const colors: Record<string, string> = {
                  agent: '#00d4ff22', tool: '#3fb95022',
                  condition: '#d2992222', human: '#bc8cff22',
                }
                return colors[n.type || ''] || '#ffffff11'
              }}
              maskColor="rgba(0,0,0,0.7)"
            />
            <Panel position="top-left">
              <div style={{
                background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)',
                borderRadius: 8, padding: '10px 14px', fontSize: 12, color: 'var(--text-muted)',
              }}>
                {nodes.length} nodes · {edges.length} edges
                {running && <span style={{ color: 'var(--green)', marginLeft: 8 }}>● RUNNING</span>}
              </div>
            </Panel>
          </ReactFlow>
        </div>

        {/* Node config panel */}
        {selectedNode && (
          <NodePanel
            node={selectedNode}
            agents={agents}
            onUpdate={(data: any) => {
              setNodes(ns => ns.map(n => n.id === selectedNode.id ? { ...n, data: { ...n.data, ...data } } : n))
            }}
            onClose={() => setSelectedNode(null)}
          />
        )}

        {/* Execution panel */}
        {showExecPanel && (
          <ExecutionPanel
            events={executionEvents}
            executionId={executionId}
            running={running}
            onClose={() => setShowExecPanel(false)}
          />
        )}
      </div>
    </div>
  )
}

function btnStyle(variant: 'primary' | 'secondary' | 'ghost' | 'danger') {
  const base: React.CSSProperties = {
    display: 'flex', alignItems: 'center', gap: 6,
    padding: '6px 12px', borderRadius: 6, cursor: 'pointer',
    fontSize: 13, fontWeight: 500, transition: 'all 0.15s',
  }
  const variants: Record<string, React.CSSProperties> = {
    primary:   { background: 'var(--accent)', color: '#000', border: 'none' },
    secondary: { background: 'var(--bg-hover)', color: 'var(--text-primary)', border: '1px solid var(--border-default)' },
    ghost:     { background: 'transparent', color: 'var(--text-secondary)', border: 'none' },
    danger:    { background: 'rgba(248,81,73,0.15)', color: 'var(--red)', border: '1px solid rgba(248,81,73,0.3)' },
  }
  return { ...base, ...variants[variant] }
}
