#!/usr/bin/env python3
"""
AgentFlow End-to-End Demo
─────────────────────────
Demonstrates the full platform in action:
  1. Register user + get tokens
  2. Create 3 specialized agents
  3. Build a multi-agent research workflow
  4. Execute it and stream live events
  5. Inspect agent memory
  6. View execution checkpoints (time-travel)

Run from the repo root:
    python demo.py                          # vs localhost
    python demo.py --url https://your.app  # vs deployed instance
"""
import asyncio
import json
import sys
import time
import argparse
from datetime import datetime

import httpx

BASE_URL = "http://localhost:8000/api/v1"
HEADERS = {}


# ── Helpers ───────────────────────────────────────────────────────────────────

def c(text: str, color: str) -> str:
    colors = {"cyan": "\033[96m", "green": "\033[92m", "yellow": "\033[93m",
              "red": "\033[91m", "blue": "\033[94m", "dim": "\033[2m", "bold": "\033[1m"}
    return f"{colors.get(color,'')}{text}\033[0m"


def step(n: int, title: str):
    print(f"\n{c(f'  Step {n}', 'cyan')} {c('─' * 40, 'dim')}")
    print(f"  {c('▶', 'cyan')} {c(title, 'bold')}")


def ok(msg: str):   print(f"  {c('✓', 'green')} {msg}")
def info(msg: str): print(f"  {c('·', 'dim')} {c(msg, 'dim')}")
def warn(msg: str): print(f"  {c('!', 'yellow')} {msg}")
def fail(msg: str): print(f"  {c('✗', 'red')} {msg}"); sys.exit(1)


def post(path: str, data: dict) -> dict:
    r = httpx.post(f"{BASE_URL}{path}", json=data, headers=HEADERS, timeout=30)
    if r.status_code >= 400:
        fail(f"POST {path} → {r.status_code}: {r.json()}")
    return r.json()


def get(path: str) -> dict:
    r = httpx.get(f"{BASE_URL}{path}", headers=HEADERS, timeout=30)
    if r.status_code >= 400:
        warn(f"GET {path} → {r.status_code}")
        return {}
    return r.json()


def patch(path: str, data: dict) -> dict:
    r = httpx.patch(f"{BASE_URL}{path}", json=data, headers=HEADERS, timeout=30)
    return r.json()


# ── Demo ──────────────────────────────────────────────────────────────────────

def run_demo(base_url: str):
    global BASE_URL, HEADERS
    BASE_URL = f"{base_url}/api/v1"

    print()
    print(c("  ╔═══════════════════════════════════════════╗", "cyan"))
    print(c("  ║     AgentFlow  ·  End-to-End Demo         ║", "cyan"))
    print(c("  ╚═══════════════════════════════════════════╝", "cyan"))
    print(f"  {c('Target:', 'dim')} {base_url}")
    print(f"  {c('Time:  ', 'dim')} {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    # ── 1. Health check ───────────────────────────────────────────────────────
    step(1, "Platform health check")
    r = httpx.get(f"{base_url}/health", timeout=10)
    if r.status_code != 200:
        fail(f"API not reachable at {base_url}")
    health = r.json()
    ok(f"Platform is {c(health['status'], 'green')}  version={health['version']}")

    # ── 2. Register / Login ───────────────────────────────────────────────────
    step(2, "Authenticate (register or login)")
    email = f"demo_{int(time.time())}@agentflow.dev"
    try:
        auth = post("/auth/register", {
            "email": email, "password": "demo-pass-123",
            "full_name": "Demo User", "tenant_id": "demo-tenant",
        })
        ok(f"Registered as {c(email, 'cyan')}")
    except SystemExit:
        auth = post("/auth/login", {"email": "admin@agentflow.dev", "password": "changeme"})
        ok(f"Logged in as {c('admin@agentflow.dev', 'cyan')}")

    token = auth["access_token"]
    HEADERS["Authorization"] = f"Bearer {token}"
    info(f"Token: {token[:32]}…")

    # ── 3. Create agents ──────────────────────────────────────────────────────
    step(3, "Create 3 specialized agents")
    agents_data = [
        {
            "name": "WebResearcher",
            "role": "Senior Web Research Specialist",
            "goal": "Find current, accurate information from the web and synthesize it clearly.",
            "backstory": "Expert at finding needle-in-a-haystack information, validating sources, and structuring findings.",
            "model": "gpt-4o-mini",
            "provider": "openai",
            "temperature": 0.3,
            "tools": ["web_search", "text_summarizer"],
            "memory_enabled": True,
        },
        {
            "name": "DataAnalyst",
            "role": "Quantitative Data Analyst",
            "goal": "Perform statistical analysis and generate structured insights from raw data.",
            "backstory": "PhD-level statistician with expertise in time series, regression, and data visualization.",
            "model": "gpt-4o-mini",
            "provider": "openai",
            "temperature": 0.1,
            "tools": ["code_executor", "calculator"],
            "memory_enabled": True,
        },
        {
            "name": "ReportWriter",
            "role": "Executive Communications Specialist",
            "goal": "Transform technical findings into concise, compelling executive summaries.",
            "backstory": "20 years writing C-suite briefings at top consulting firms. Masters of clarity and actionability.",
            "model": "gpt-4o",
            "provider": "openai",
            "temperature": 0.7,
            "tools": ["text_summarizer"],
            "memory_enabled": False,
        },
    ]

    agent_ids = {}
    for a in agents_data:
        agent = post("/agents", a)
        agent_ids[a["name"]] = agent["id"]
        ok(f"Created agent: {c(a['name'], 'cyan')}  id={agent['id'][:12]}…  model={a['model']}")

    # ── 4. Build workflow ─────────────────────────────────────────────────────
    step(4, "Build multi-agent research workflow")
    workflow_def = {
        "nodes": [
            {"id": "trigger",   "type": "trigger",   "position": {"x": 50,   "y": 180},
             "data": {"label": "Research Trigger", "config": {"trigger_type": "manual"}}},
            {"id": "research",  "type": "agent",     "position": {"x": 280,  "y": 180},
             "data": {"label": "WebResearcher", "config": {
                 "agent_id": agent_ids["WebResearcher"], "model": "gpt-4o-mini",
                 "tools": ["web_search", "text_summarizer"], "memory_enabled": True}}},
            {"id": "condition", "type": "condition", "position": {"x": 520,  "y": 180},
             "data": {"label": "Data-heavy?", "config": {
                 "expression": "state.context.get('requires_analysis', False)",
                 "true_target": "analysis", "false_target": "writing"}}},
            {"id": "analysis",  "type": "agent",     "position": {"x": 760,  "y": 80},
             "data": {"label": "DataAnalyst", "config": {
                 "agent_id": agent_ids["DataAnalyst"], "model": "gpt-4o-mini",
                 "tools": ["code_executor", "calculator"]}}},
            {"id": "human",     "type": "human",     "position": {"x": 760,  "y": 280},
             "data": {"label": "Quick Approval", "config": {
                 "message": "Research complete. Approve to generate report?", "timeout": 60}}},
            {"id": "writing",   "type": "agent",     "position": {"x": 1000, "y": 180},
             "data": {"label": "ReportWriter", "config": {
                 "agent_id": agent_ids["ReportWriter"], "model": "gpt-4o",
                 "tools": ["text_summarizer"]}}},
        ],
        "edges": [
            {"id": "e1", "source": "trigger",   "target": "research",  "animated": True},
            {"id": "e2", "source": "research",  "target": "condition", "animated": True},
            {"id": "e3", "source": "condition", "target": "analysis",  "animated": True, "label": "yes"},
            {"id": "e4", "source": "condition", "target": "human",     "animated": True, "label": "no"},
            {"id": "e5", "source": "analysis",  "target": "writing",   "animated": True},
            {"id": "e6", "source": "human",     "target": "writing",   "animated": True},
        ],
        "settings": {"max_iterations": 30, "timeout_seconds": 600, "process_type": "sequential"},
    }

    workflow = post("/workflows", {
        "name": "AI Trends Research Pipeline (Demo)",
        "description": "Research → Conditional Analysis → Human Gate → Report",
        "definition": workflow_def,
        "tags": ["demo", "research"],
    })
    ok(f"Workflow created: {c(workflow['name'], 'cyan')}")
    info(f"  {len(workflow_def['nodes'])} nodes, {len(workflow_def['edges'])} edges, version={workflow['version']}")

    # ── 5. Execute workflow ───────────────────────────────────────────────────
    step(5, "Execute the workflow")
    execution = post(f"/workflows/{workflow['id']}/run", {
        "input_data": {
            "task": "Research the latest AI agent frameworks in 2025 — key players, adoption trends, and technical differentiators",
            "requires_analysis": False,
        }
    })
    exec_id = execution["id"]
    ok(f"Execution queued: {c(exec_id[:16], 'cyan')}…")
    info(f"  Status: {execution['status']}")

    # ── 6. Stream events ──────────────────────────────────────────────────────
    step(6, "Stream live execution events (SSE)")
    info("Connecting to SSE stream… (ctrl+C to skip)")
    events_received = 0
    t0 = time.time()

    try:
        import threading
        stop = threading.Event()

        def stream_thread():
            nonlocal events_received
            try:
                with httpx.stream(
                    "GET",
                    f"{BASE_URL}/stream/{exec_id}",
                    headers={**HEADERS, "Accept": "text/event-stream"},
                    timeout=30,
                ) as resp:
                    for line in resp.iter_lines():
                        if stop.is_set():
                            break
                        if line.startswith("data: "):
                            try:
                                ev = json.loads(line[6:])
                                events_received += 1
                                ev_type = ev.get("type", "event")
                                node = ev.get("node_id", "")
                                if ev_type == "node_status":
                                    status = ev.get("status", "")
                                    marker = c("▶", "cyan") if status == "running" else c("✓", "green") if status == "completed" else c("✗", "red")
                                    print(f"  {marker} node={c(node, 'cyan')}  status={status}")
                                elif ev_type == "agent_thought":
                                    print(f"  {c('💭', 'dim')} {c(ev.get('agent_name','?'), 'yellow')} thinking… iter={ev.get('iteration',0)}")
                                elif ev_type in ("execution_complete", "execution_failed"):
                                    sym = c("✓ COMPLETE", "green") if ev_type == "execution_complete" else c("✗ FAILED", "red")
                                    print(f"  {sym}  ({events_received} events in {time.time()-t0:.1f}s)")
                                    stop.set()
                                    break
                                elif ev_type == "interrupt":
                                    print(f"  {c('⏸ INTERRUPT', 'yellow')}  {ev.get('message','')}")
                                    stop.set()
                                    break
                            except json.JSONDecodeError:
                                pass
            except Exception as e:
                print(f"  {c('stream ended', 'dim')} ({e})")

        t = __import__("threading").Thread(target=stream_thread, daemon=True)
        t.start()
        t.join(timeout=25)
        stop.set()

    except KeyboardInterrupt:
        warn("Stream skipped by user")

    if events_received == 0:
        info("No stream events (worker may not be running — events will process async)")

    # ── 7. Check execution status ─────────────────────────────────────────────
    step(7, "Poll execution status")
    time.sleep(2)
    exec_status = get(f"/executions/{exec_id}")
    status = exec_status.get("status", "unknown")
    color = "green" if status == "completed" else "yellow" if status in ("running","pending") else "red"
    ok(f"Status: {c(status, color)}")
    if exec_status.get("duration_ms"):
        info(f"Duration: {exec_status['duration_ms']}ms")
    if exec_status.get("tokens_used"):
        info(f"Tokens:  {exec_status['tokens_used']:,}  cost=${exec_status.get('cost_usd',0):.4f}")

    # ── 8. View checkpoints ───────────────────────────────────────────────────
    step(8, "Time-travel: view execution checkpoints")
    checkpoints = get(f"/executions/{exec_id}/checkpoints")
    if isinstance(checkpoints, list) and checkpoints:
        ok(f"Found {len(checkpoints)} checkpoint(s):")
        for cp in checkpoints[:5]:
            print(f"    step={cp.get('step','?')}  node={cp.get('node','?')}  t={cp.get('timestamp','?')[:19]}")
    else:
        info("No checkpoints yet (execution pending)")

    # ── 9. Agent memory ───────────────────────────────────────────────────────
    step(9, "Inspect agent long-term memory")
    researcher_id = agent_ids["WebResearcher"]
    memories = get(f"/memory/agents/{researcher_id}?query=AI+frameworks&limit=5")
    if isinstance(memories, list) and memories:
        ok(f"Found {len(memories)} memory entries for WebResearcher:")
        for m in memories[:3]:
            content_preview = m.get("content", "")[:70]
            print(f"    [{m.get('type','?')}]  {c(content_preview, 'dim')}…")
    else:
        info("No memories yet (agent hasn't run end-to-end)")

    # ── 10. SDK usage demo ────────────────────────────────────────────────────
    step(10, "SDK usage snippet")
    print(f"""
  {c('# Install the SDK (or use sdk.py directly)', 'dim')}
  {c('from sdk import AgentFlowClient', 'cyan')}

  client = AgentFlowClient(
      base_url="{base_url}",
      email="admin@agentflow.dev",
      password="changeme",
  )

  {c('# List your agents', 'dim')}
  {c('agents = client.agents.list()', 'cyan')}

  {c('# Run a workflow and stream events', 'dim')}
  {c('exec_ = client.workflows.run("{workflow["id"][:8]}…")', 'cyan')}
  {c('for event in client.stream(exec_["id"]):', 'cyan')}
  {c('    print(event["type"], event.get("node_id"))', 'cyan')}
""")

    # ── Summary ───────────────────────────────────────────────────────────────
    total_time = time.time() - t0
    print(c("  ╔═══════════════════════════════════════════╗", "green"))
    print(c("  ║           Demo Complete  ✓                ║", "green"))
    print(c("  ╚═══════════════════════════════════════════╝", "green"))
    print(f"""
  {c('What was demonstrated:', 'bold')}

  ✓  JWT authentication with tenant isolation
  ✓  3 agents with roles, goals, tools, memory
  ✓  6-node workflow: Trigger → Agent → Condition →
       Human-in-loop / Analysis → Report Writer
  ✓  Async execution via Celery (status: {c(status, 'yellow')})
  ✓  Live SSE event streaming ({events_received} events received)
  ✓  PostgreSQL checkpointing (time-travel ready)
  ✓  Long-term memory in Qdrant

  {c('Next steps:', 'bold')}
  → Open {c(f'{base_url.replace("/api/v1","")}/docs', 'cyan')} for full API docs
  → Navigate to {c('http://localhost:5173', 'cyan')} for the visual builder
  → Run {c('make test', 'cyan')} for the full test suite
  → Run {c('python backend/seed.py', 'cyan')} for demo data

  {c(f'Total time: {total_time:.1f}s', 'dim')}
""")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AgentFlow End-to-End Demo")
    parser.add_argument("--url", default="http://localhost:8000", help="AgentFlow API base URL")
    args = parser.parse_args()
    run_demo(args.url)
