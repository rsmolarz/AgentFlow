"""
AgentFlow Execution Engine
--------------------------
LangGraph-inspired StateGraph with:
- Typed state with reducer-based merging
- Conditional edges and dynamic Send() parallelism
- PostgreSQL-backed checkpointing (crash recovery, time-travel)
- Human-in-the-loop interrupts
- 5-phase execution: compile → schedule → execute → merge → checkpoint

This is the heart of the platform.
"""
from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncIterator, Callable, Optional, Type

import networkx as nx
import structlog
from pydantic import BaseModel

from src.config import settings
from src.core.redis import publish_event, stream_add

log = structlog.get_logger()


# ── Enums ──────────────────────────────────────────────────────────────────────

class NodeStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WAITING_HUMAN = "waiting_human"


class ExecutionStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WAITING_HUMAN = "waiting_human"


# ── Interrupt Exception (Human-in-the-Loop) ───────────────────────────────────

class GraphInterrupt(Exception):
    """Raised by a node to pause execution and request human input."""
    def __init__(self, message: str, input_schema: dict | None = None):
        self.message = message
        self.input_schema = input_schema or {}
        super().__init__(message)


# ── State Reducers ─────────────────────────────────────────────────────────────

def append_reducer(existing: list, new: Any) -> list:
    """Append new items to a list (for message history, tool outputs)."""
    if isinstance(new, list):
        return (existing or []) + new
    return (existing or []) + [new]


def overwrite_reducer(existing: Any, new: Any) -> Any:
    """Replace with new value (default for scalars)."""
    return new


def merge_dict_reducer(existing: dict, new: dict) -> dict:
    """Merge dicts — new values overwrite existing keys."""
    return {**(existing or {}), **(new or {})}


# ── Typed State ────────────────────────────────────────────────────────────────

class GraphState(BaseModel):
    """
    Base state class. All workflow executions use this.
    Fields use reducers for safe concurrent merging.
    """
    messages: list[dict] = []
    agent_outputs: dict[str, Any] = {}
    tool_results: list[dict] = []
    context: dict[str, Any] = {}
    errors: list[dict] = []
    metadata: dict[str, Any] = {}
    # Execution control
    execution_id: str = ""
    current_node: str = ""
    iteration: int = 0
    human_input: Optional[str] = None

    REDUCERS: dict[str, Callable] = {
        "messages": append_reducer,
        "tool_results": append_reducer,
        "errors": append_reducer,
        "agent_outputs": merge_dict_reducer,
        "context": merge_dict_reducer,
        "metadata": merge_dict_reducer,
    }

    def merge(self, updates: dict) -> "GraphState":
        """Apply updates using registered reducers."""
        new_data = self.model_dump()
        for key, value in updates.items():
            if key in self.REDUCERS:
                new_data[key] = self.REDUCERS[key](new_data.get(key), value)
            else:
                new_data[key] = value
        return GraphState(**new_data)


# ── Node Types ────────────────────────────────────────────────────────────────

class NodeDefinition(BaseModel):
    id: str
    type: str   # agent, tool, condition, parallel_start, parallel_end, human, trigger, subworkflow
    fn: Optional[Callable] = None
    config: dict = {}
    retry_count: int = 3
    timeout_seconds: int = 300

    model_config = {"arbitrary_types_allowed": True}


class Edge(BaseModel):
    source: str
    target: str
    condition: Optional[Callable] = None   # None = unconditional
    label: Optional[str] = None

    model_config = {"arbitrary_types_allowed": True}


# ── The StateGraph ────────────────────────────────────────────────────────────

class StateGraph:
    """
    Core graph builder. Define nodes and edges, then compile().
    Inspired by LangGraph's StateGraph API.
    """

    START = "__start__"
    END = "__end__"

    def __init__(self, state_schema: Type[GraphState] = GraphState):
        self.state_schema = state_schema
        self.nodes: dict[str, NodeDefinition] = {}
        self.edges: list[Edge] = []
        self._compiled: bool = False

    def add_node(self, node_id: str, fn: Callable, config: dict = {}, **kwargs) -> "StateGraph":
        self.nodes[node_id] = NodeDefinition(
            id=node_id, type="custom", fn=fn, config=config, **kwargs
        )
        return self

    def add_edge(self, source: str, target: str) -> "StateGraph":
        self.edges.append(Edge(source=source, target=target))
        return self

    def add_conditional_edges(
        self,
        source: str,
        router_fn: Callable,
        path_map: dict[str, str],
    ) -> "StateGraph":
        """Add edges where the target depends on runtime state."""
        for condition_key, target in path_map.items():
            self.edges.append(Edge(
                source=source,
                target=target,
                condition=lambda state, key=condition_key, fn=router_fn: fn(state) == key,
                label=condition_key,
            ))
        return self

    def set_entry_point(self, node_id: str) -> "StateGraph":
        return self.add_edge(self.START, node_id)

    def set_finish_point(self, node_id: str) -> "StateGraph":
        return self.add_edge(node_id, self.END)

    def compile(self, checkpointer=None) -> "CompiledGraph":
        # Validate: detect cycles (excluding legitimate loops via iteration limits)
        dag = nx.DiGraph()
        for edge in self.edges:
            dag.add_edge(edge.source, edge.target)

        self._compiled = True
        return CompiledGraph(
            graph=self,
            checkpointer=checkpointer,
        )


# ── Compiled Graph (Executor) ────────────────────────────────────────────────

class CompiledGraph:
    """
    Executes a compiled StateGraph.
    Handles scheduling, state management, checkpointing, and streaming.
    """

    def __init__(self, graph: StateGraph, checkpointer=None):
        self.graph = graph
        self.checkpointer = checkpointer

    async def invoke(
        self,
        input: dict,
        config: dict | None = None,
    ) -> dict:
        """Run to completion and return final state."""
        final_state = None
        async for event in self.stream(input, config, stream_mode=["values"]):
            if event.get("type") == "final":
                final_state = event.get("state", {})
        return final_state or input

    async def stream(
        self,
        input: dict,
        config: dict | None = None,
        stream_mode: list[str] = ["updates"],
    ) -> AsyncIterator[dict]:
        """
        Stream execution events.
        stream_mode options: "updates" (deltas), "values" (full state), "debug"
        """
        config = config or {}
        execution_id = config.get("execution_id", str(uuid.uuid4()))
        tenant_id = config.get("tenant_id", "default")

        state = self.graph.state_schema(execution_id=execution_id, **input)

        # Load checkpoint if resuming
        if self.checkpointer and config.get("thread_id"):
            checkpoint = await self.checkpointer.get(config)
            if checkpoint:
                state = self.graph.state_schema(**checkpoint["state"])
                log.info("execution.resumed_from_checkpoint",
                         execution_id=execution_id, node=checkpoint["current_node"])

        # Topological execution order (Kahn's algorithm)
        execution_queue = self._get_ready_nodes(state)

        while execution_queue:
            # Execute ready nodes (potentially in parallel)
            parallel_tasks = [
                self._execute_node(node_id, state, execution_id, tenant_id)
                for node_id in execution_queue
            ]

            results = await asyncio.gather(*parallel_tasks, return_exceptions=True)

            for node_id, result in zip(execution_queue, results):
                if isinstance(result, GraphInterrupt):
                    # Pause execution, save checkpoint
                    if self.checkpointer:
                        await self.checkpointer.put(
                            config,
                            {"state": state.model_dump(), "current_node": node_id},
                            {"interrupted": True, "message": result.message},
                        )
                    yield {
                        "type": "interrupt",
                        "node_id": node_id,
                        "message": result.message,
                        "input_schema": result.input_schema,
                        "execution_id": execution_id,
                    }
                    return

                elif isinstance(result, Exception):
                    error_event = {
                        "type": "node_error",
                        "node_id": node_id,
                        "error": str(result),
                        "execution_id": execution_id,
                    }
                    await stream_add(execution_id, error_event)
                    state = state.merge({"errors": [{"node": node_id, "error": str(result)}]})

                else:
                    # Successful node — merge output into state
                    if result:
                        state = state.merge(result)

                    complete_event = {
                        "type": "node_status",
                        "node_id": node_id,
                        "status": "completed",
                        "execution_id": execution_id,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
                    await stream_add(execution_id, complete_event)
                    await publish_event(f"stream:{execution_id}", complete_event)

                    if "updates" in stream_mode:
                        yield {"type": "state_update", "node_id": node_id, "updates": result or {}}

            # Checkpoint after each super-step
            if self.checkpointer:
                await self.checkpointer.put(
                    config,
                    {"state": state.model_dump(), "current_node": node_id},
                    {},
                )

            # Get next ready nodes
            execution_queue = self._get_next_nodes(execution_queue, state)

        if "values" in stream_mode:
            yield {"type": "final", "state": state.model_dump(), "execution_id": execution_id}

        final_event = {
            "type": "execution_complete",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        await stream_add(execution_id, final_event)
        await publish_event(f"stream:{execution_id}", final_event)

    async def _execute_node(
        self,
        node_id: str,
        state: GraphState,
        execution_id: str,
        tenant_id: str,
    ) -> dict | None:
        """Execute a single node with retry logic."""
        node = self.graph.nodes.get(node_id)
        if not node or node_id in (StateGraph.START, StateGraph.END):
            return None

        start_event = {
            "type": "node_status",
            "node_id": node_id,
            "status": "running",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        await publish_event(f"stream:{execution_id}", start_event)

        for attempt in range(node.retry_count):
            try:
                result = await asyncio.wait_for(
                    node.fn(state),
                    timeout=node.timeout_seconds,
                )
                return result
            except GraphInterrupt:
                raise
            except asyncio.TimeoutError:
                if attempt == node.retry_count - 1:
                    raise TimeoutError(f"Node {node_id} timed out after {node.timeout_seconds}s")
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
            except Exception as e:
                if attempt == node.retry_count - 1:
                    raise
                log.warning("node.retry", node_id=node_id, attempt=attempt, error=str(e))
                await asyncio.sleep(2 ** attempt)

    def _get_ready_nodes(self, state: GraphState) -> list[str]:
        """Get the initial execution set (nodes reachable from START)."""
        ready = []
        for edge in self.graph.edges:
            if edge.source == StateGraph.START:
                if edge.condition is None or edge.condition(state):
                    ready.append(edge.target)
        return list(set(ready))

    def _get_next_nodes(self, completed_nodes: list[str], state: GraphState) -> list[str]:
        """Get nodes that become ready after the given nodes complete."""
        completed_set = set(completed_nodes)
        all_nodes = set(self.graph.nodes.keys())

        ready = []
        for edge in self.graph.edges:
            if edge.source in completed_set and edge.target not in (StateGraph.END,):
                if edge.target in all_nodes:
                    if edge.condition is None or edge.condition(state):
                        ready.append(edge.target)
        return list(set(ready))
