"""
4-Tier Agent Memory System
──────────────────────────
Tier 1: Short-term   — Sliding window context + auto-summarization (Redis TTL)
Tier 2: Working      — Agent scratchpad / in-progress reasoning (Redis + Postgres checkpoint)
Tier 3: Long-term    — Vector store (Qdrant per-tenant collection) with composite retrieval
Tier 4: Episodic     — Structured experience records with temporal + semantic indexing
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

import structlog
from sqlmodel import Field, SQLModel

log = structlog.get_logger()


# ── Memory Entry ───────────────────────────────────────────────────────────────

@dataclass
class MemoryEntry:
    id: str
    content: str
    agent_id: str
    tenant_id: str
    memory_type: str  # short_term | working | long_term | episodic | entity
    importance: float = 0.5
    access_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict = field(default_factory=dict)

    def to_qdrant_point(self, vector: list[float]) -> dict:
        return {
            "id": self.id,
            "vector": vector,
            "payload": {
                "content": self.content,
                "agent_id": self.agent_id,
                "tenant_id": self.tenant_id,
                "memory_type": self.memory_type,
                "importance": self.importance,
                "access_count": self.access_count,
                "created_at": self.created_at,
                **self.metadata,
            },
        }


# ── Database Model for Episodic Records ───────────────────────────────────────

class EpisodicRecord(SQLModel, table=True):
    __tablename__ = "episodic_records"

    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    agent_id: str = Field(index=True)
    tenant_id: str = Field(index=True)
    task_description: str
    actions_taken: str  # JSON list
    outcome: str
    self_assessment: str
    success: bool
    duration_ms: int = 0
    tokens_used: int = 0
    importance: float = 0.5
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ── Memory Manager ─────────────────────────────────────────────────────────────

class MemoryManager:
    """
    Orchestrates all 4 memory tiers with tenant-scoped retrieval.
    Composite ranking: 0.5 semantic similarity + 0.3 recency + 0.2 importance
    """

    COMPOSITE_WEIGHTS = {"similarity": 0.5, "recency": 0.3, "importance": 0.2}

    def __init__(self, tenant_id: str, agent_id: str):
        self.tenant_id = tenant_id
        self.agent_id = agent_id
        self._collection_name = f"tenant_{tenant_id.replace('-', '_')}"

    async def remember(self, content: str, metadata: Any) -> str:
        """Store a memory entry. Auto-classifies tier by content and metadata."""
        memory_id = str(uuid.uuid4())
        memory_type = getattr(metadata, "memory_type", "long_term")
        importance = await self._assess_importance(content)

        entry = MemoryEntry(
            id=memory_id,
            content=content,
            agent_id=self.agent_id,
            tenant_id=self.tenant_id,
            memory_type=memory_type,
            importance=importance,
        )

        # Store in vector DB for semantic retrieval
        try:
            vector = await self._embed(content)
            await self._upsert_qdrant(entry, vector)
        except Exception as e:
            log.warning("memory.qdrant_unavailable", error=str(e))
            # Fallback: cache in Redis
            await self._cache_in_redis(entry)

        return memory_id

    async def recall(
        self,
        query: str,
        tenant_id: str,
        agent_id: str,
        top_k: int = 10,
    ) -> list[MemoryEntry]:
        """
        Composite retrieval:
        1. ANN search in Qdrant (over-fetch 3x)
        2. Re-rank with recency decay and importance weighting
        3. Return top_k results
        """
        try:
            query_vector = await self._embed(query)
            raw_results = await self._search_qdrant(query_vector, agent_id, top_k * 3)
            ranked = self._composite_rank(raw_results, top_k)
            return ranked
        except Exception as e:
            log.warning("memory.recall_failed", error=str(e))
            return await self._recall_from_redis(query, agent_id, top_k)

    async def get_working_memory(self, execution_id: str) -> dict:
        """Get the agent's current scratchpad."""
        from src.core.redis import cache_get
        data = await cache_get(f"working_mem:{self.tenant_id}:{self.agent_id}:{execution_id}")
        return data or {
            "current_task": "",
            "intermediate_results": [],
            "hypotheses": [],
            "planned_steps": [],
        }

    async def update_working_memory(self, execution_id: str, updates: dict) -> None:
        """Update the agent's scratchpad."""
        from src.core.redis import cache_get, cache_set
        current = await self.get_working_memory(execution_id)
        current.update(updates)
        await cache_set(
            f"working_mem:{self.tenant_id}:{self.agent_id}:{execution_id}",
            current,
            ttl_seconds=86400,  # 24 hours
        )

    async def record_episode(
        self,
        task: str,
        actions: list[str],
        outcome: str,
        success: bool,
        **kwargs,
    ) -> None:
        """Store an episodic memory for future experiential learning."""
        from src.core.database import async_session_factory
        record = EpisodicRecord(
            agent_id=self.agent_id,
            tenant_id=self.tenant_id,
            task_description=task,
            actions_taken=json.dumps(actions),
            outcome=outcome,
            self_assessment=kwargs.get("self_assessment", ""),
            success=success,
            duration_ms=kwargs.get("duration_ms", 0),
            tokens_used=kwargs.get("tokens_used", 0),
        )
        async with async_session_factory() as session:
            session.add(record)
            await session.commit()

    # ── Private helpers ──────────────────────────────────────────────────────

    async def _embed(self, text: str) -> list[float]:
        """Generate embedding using configured provider."""
        from src.config import settings
        try:
            import openai
            client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
            response = await client.embeddings.create(
                model=settings.DEFAULT_EMBEDDING_MODEL,
                input=text,
            )
            return response.data[0].embedding
        except Exception:
            # Fallback: zero vector (won't be useful but won't crash)
            return [0.0] * settings.EMBEDDING_DIMENSIONS

    async def _assess_importance(self, content: str) -> float:
        """
        Assess importance of a memory on a 0-1 scale.
        Simple heuristic: length + keyword signals.
        In production: use a lightweight LLM call.
        """
        high_importance_signals = [
            "error", "failed", "success", "important", "critical",
            "decision", "result", "conclusion", "learned", "insight",
        ]
        content_lower = content.lower()
        signal_count = sum(1 for s in high_importance_signals if s in content_lower)
        base_score = min(0.3 + (len(content) / 2000), 0.6)
        signal_boost = min(signal_count * 0.08, 0.4)
        return round(min(base_score + signal_boost, 1.0), 3)

    async def _upsert_qdrant(self, entry: MemoryEntry, vector: list[float]) -> None:
        from qdrant_client import AsyncQdrantClient
        from qdrant_client.models import Distance, VectorParams, PointStruct
        from src.config import settings

        client = AsyncQdrantClient(url=settings.QDRANT_URL, api_key=settings.QDRANT_API_KEY)

        # Ensure collection exists
        try:
            await client.get_collection(self._collection_name)
        except Exception:
            await client.create_collection(
                collection_name=self._collection_name,
                vectors_config=VectorParams(size=len(vector), distance=Distance.COSINE),
            )

        await client.upsert(
            collection_name=self._collection_name,
            points=[PointStruct(**entry.to_qdrant_point(vector))],
        )
        await client.close()

    async def _search_qdrant(
        self, query_vector: list[float], agent_id: str, limit: int
    ) -> list[tuple[MemoryEntry, float]]:
        from qdrant_client import AsyncQdrantClient
        from qdrant_client.models import Filter, FieldCondition, MatchValue
        from src.config import settings

        client = AsyncQdrantClient(url=settings.QDRANT_URL, api_key=settings.QDRANT_API_KEY)

        results = await client.search(
            collection_name=self._collection_name,
            query_vector=query_vector,
            query_filter=Filter(
                must=[FieldCondition(key="agent_id", match=MatchValue(value=agent_id))]
            ),
            limit=limit,
            with_payload=True,
        )
        await client.close()

        entries = []
        for hit in results:
            p = hit.payload or {}
            entry = MemoryEntry(
                id=str(hit.id),
                content=p.get("content", ""),
                agent_id=p.get("agent_id", ""),
                tenant_id=p.get("tenant_id", ""),
                memory_type=p.get("memory_type", "long_term"),
                importance=p.get("importance", 0.5),
                access_count=p.get("access_count", 0),
                created_at=p.get("created_at", ""),
            )
            entries.append((entry, hit.score))

        return entries

    def _composite_rank(
        self, results: list[tuple[MemoryEntry, float]], top_k: int
    ) -> list[MemoryEntry]:
        """Re-rank results using composite score."""
        from datetime import datetime
        now = datetime.now(timezone.utc)
        scored = []
        for entry, similarity in results:
            # Recency decay
            try:
                created = datetime.fromisoformat(entry.created_at.replace("Z", "+00:00"))
                age_hours = (now - created).total_seconds() / 3600
                recency = 1.0 / (1.0 + age_hours / 168)  # Half-life ~7 days
            except Exception:
                recency = 0.5

            composite = (
                self.COMPOSITE_WEIGHTS["similarity"] * similarity
                + self.COMPOSITE_WEIGHTS["recency"] * recency
                + self.COMPOSITE_WEIGHTS["importance"] * entry.importance
            )
            scored.append((entry, composite))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [entry for entry, _ in scored[:top_k]]

    async def _cache_in_redis(self, entry: MemoryEntry) -> None:
        from src.core.redis import cache_set
        key = f"mem:{self.tenant_id}:{self.agent_id}:{entry.id}"
        await cache_set(key, {
            "content": entry.content,
            "type": entry.memory_type,
            "importance": entry.importance,
        }, ttl_seconds=3600)

    async def _recall_from_redis(
        self, query: str, agent_id: str, top_k: int
    ) -> list[MemoryEntry]:
        """Fallback: keyword-based retrieval from Redis cache."""
        return []
