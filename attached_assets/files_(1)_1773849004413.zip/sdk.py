"""
AgentFlow Python SDK
────────────────────
Programmatic client for the AgentFlow API.
Supports sync and async usage.

Install: pip install agentflow-sdk  (or use this file directly)

Usage:
    from sdk import AgentFlowClient

    client = AgentFlowClient(base_url="http://localhost:8000", api_key="af_live_...")

    # Create an agent
    agent = client.agents.create(
        name="My Agent",
        role="Research Analyst",
        goal="Find market insights",
        backstory="Expert researcher",
        model="gpt-4o",
    )

    # Run a workflow
    execution = client.workflows.run("wf_id", input_data={"topic": "AI"})

    # Stream events
    for event in client.stream(execution.id):
        print(event)
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Generator, Iterator

import httpx


@dataclass
class AgentFlowClient:
    base_url: str = "http://localhost:8000"
    api_key: str | None = None
    email: str | None = None
    password: str | None = None
    _token: str | None = None
    _http: httpx.Client = field(default=None, init=False, repr=False)

    def __post_init__(self):
        self._http = httpx.Client(base_url=f"{self.base_url}/api/v1", timeout=60)
        if self.api_key:
            self._http.headers["X-API-Key"] = self.api_key
        elif self.email and self.password:
            self._authenticate()

    def _authenticate(self) -> None:
        resp = self._http.post("/auth/login", json={"email": self.email, "password": self.password})
        resp.raise_for_status()
        self._token = resp.json()["access_token"]
        self._http.headers["Authorization"] = f"Bearer {self._token}"

    def _request(self, method: str, path: str, **kwargs) -> Any:
        resp = self._http.request(method, path, **kwargs)
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise AgentFlowError(
                f"HTTP {resp.status_code}: {resp.json().get('detail', 'Unknown error')}"
            ) from e
        return resp.json() if resp.content else None

    @property
    def agents(self) -> "AgentsResource":
        return AgentsResource(self)

    @property
    def workflows(self) -> "WorkflowsResource":
        return WorkflowsResource(self)

    @property
    def executions(self) -> "ExecutionsResource":
        return ExecutionsResource(self)

    @property
    def memory(self) -> "MemoryResource":
        return MemoryResource(self)

    def stream(self, execution_id: str) -> Iterator[dict]:
        """Stream execution events via SSE."""
        headers = dict(self._http.headers)
        headers["Accept"] = "text/event-stream"
        with httpx.stream("GET", f"{self.base_url}/api/v1/stream/{execution_id}",
                          headers=headers, timeout=None) as resp:
            for line in resp.iter_lines():
                if line.startswith("data: "):
                    try:
                        yield json.loads(line[6:])
                    except json.JSONDecodeError:
                        pass


class AgentFlowError(Exception):
    pass


class AgentsResource:
    def __init__(self, client: AgentFlowClient): self._c = client

    def list(self) -> list[dict]:
        return self._c._request("GET", "/agents")

    def get(self, agent_id: str) -> dict:
        return self._c._request("GET", f"/agents/{agent_id}")

    def create(self, name: str, role: str, goal: str, backstory: str,
               model: str = "gpt-4o", provider: str = "openai",
               temperature: float = 0.7, tools: list[str] = None,
               memory_enabled: bool = True, **kwargs) -> dict:
        return self._c._request("POST", "/agents", json={
            "name": name, "role": role, "goal": goal, "backstory": backstory,
            "model": model, "provider": provider, "temperature": temperature,
            "tools": tools or [], "memory_enabled": memory_enabled, **kwargs,
        })

    def update(self, agent_id: str, **kwargs) -> dict:
        return self._c._request("PATCH", f"/agents/{agent_id}", json=kwargs)

    def delete(self, agent_id: str) -> None:
        self._c._request("DELETE", f"/agents/{agent_id}")


class WorkflowsResource:
    def __init__(self, client: AgentFlowClient): self._c = client

    def list(self) -> list[dict]:
        return self._c._request("GET", "/workflows")

    def get(self, workflow_id: str) -> dict:
        return self._c._request("GET", f"/workflows/{workflow_id}")

    def create(self, name: str, definition: dict, description: str = "",
               tags: list[str] = None) -> dict:
        return self._c._request("POST", "/workflows", json={
            "name": name, "definition": definition,
            "description": description, "tags": tags or [],
        })

    def run(self, workflow_id: str, input_data: dict = None, config: dict = None) -> dict:
        return self._c._request("POST", f"/workflows/{workflow_id}/run", json={
            "input_data": input_data or {}, "config": config or {},
        })

    def executions(self, workflow_id: str, limit: int = 20) -> list[dict]:
        return self._c._request("GET", f"/workflows/{workflow_id}/executions?limit={limit}")

    def delete(self, workflow_id: str) -> None:
        self._c._request("DELETE", f"/workflows/{workflow_id}")


class ExecutionsResource:
    def __init__(self, client: AgentFlowClient): self._c = client

    def list(self, status: str = None, limit: int = 50) -> list[dict]:
        url = f"/executions?limit={limit}"
        if status: url += f"&status={status}"
        return self._c._request("GET", url)

    def get(self, execution_id: str) -> dict:
        return self._c._request("GET", f"/executions/{execution_id}")

    def cancel(self, execution_id: str) -> dict:
        return self._c._request("POST", f"/executions/{execution_id}/cancel")

    def resume(self, execution_id: str, human_input: str) -> dict:
        return self._c._request("POST", f"/executions/{execution_id}/resume",
            json={"human_input": human_input, "execution_id": execution_id})

    def checkpoints(self, execution_id: str) -> list[dict]:
        return self._c._request("GET", f"/executions/{execution_id}/checkpoints")


class MemoryResource:
    def __init__(self, client: AgentFlowClient): self._c = client

    def search(self, agent_id: str, query: str = "", limit: int = 20) -> list[dict]:
        return self._c._request("GET", f"/memory/agents/{agent_id}?query={query}&limit={limit}")

    def clear(self, agent_id: str) -> dict:
        return self._c._request("DELETE", f"/memory/agents/{agent_id}")


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, os
    base_url = os.environ.get("AGENTFLOW_URL", "http://localhost:8000")
    api_key  = os.environ.get("AGENTFLOW_API_KEY", "")
    email    = os.environ.get("AGENTFLOW_EMAIL", "admin@agentflow.dev")
    password = os.environ.get("AGENTFLOW_PASSWORD", "changeme")

    client = AgentFlowClient(
        base_url=base_url,
        api_key=api_key or None,
        email=email if not api_key else None,
        password=password if not api_key else None,
    )

    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"

    if cmd == "agents":
        agents = client.agents.list()
        print(f"\n{'ID':<36}  {'Name':<25}  {'Model':<15}  Executions")
        print("─" * 90)
        for a in agents:
            print(f"{a['id']:<36}  {a['name']:<25}  {a['model']:<15}  {a['execution_count']}")

    elif cmd == "workflows":
        workflows = client.workflows.list()
        print(f"\n{'ID':<36}  {'Name':<30}  {'Status':<10}  Runs")
        print("─" * 90)
        for w in workflows:
            print(f"{w['id']:<36}  {w['name']:<30}  {w['status']:<10}  {w['run_count']}")

    elif cmd == "run" and len(sys.argv) > 2:
        wf_id = sys.argv[2]
        input_data = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
        exec_ = client.workflows.run(wf_id, input_data=input_data)
        print(f"\n✅ Execution started: {exec_['id']}")
        print(f"   Status: {exec_['status']}")
        print(f"\nStream events with:")
        print(f"   python sdk.py stream {exec_['id']}")

    elif cmd == "stream" and len(sys.argv) > 2:
        exec_id = sys.argv[2]
        print(f"\n📡 Streaming execution {exec_id}…\n")
        for event in client.stream(exec_id):
            print(f"  [{event.get('type', 'event'):25}] {json.dumps(event)[:100]}")
            if event.get("type") in ("execution_complete", "execution_failed"):
                break

    else:
        print("""
AgentFlow SDK CLI

Usage:
  python sdk.py agents              List all agents
  python sdk.py workflows           List all workflows
  python sdk.py run <wf_id>         Run a workflow
  python sdk.py run <wf_id> '{"k":"v"}'  Run with input
  python sdk.py stream <exec_id>    Stream execution events

Environment:
  AGENTFLOW_URL      API base URL (default: http://localhost:8000)
  AGENTFLOW_API_KEY  API key (or use email/password below)
  AGENTFLOW_EMAIL    Login email
  AGENTFLOW_PASSWORD Login password
""")
